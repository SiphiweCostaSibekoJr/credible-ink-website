
-- Credible Studios Supabase Schema
-- Run this in Supabase SQL Editor

-- Enable UUID
create extension if not exists "uuid-ossp";

-- BOOKINGS
create table bookings (
  id uuid primary key default uuid_generate_v4(),
  name text not null,
  phone text not null,
  email text not null,
  service text not null check (service in ('Tattoo','Piercing','Consultation','Custom Merch')),
  date date,
  time time,
  description text not null,
  placement text,
  size text,
  notes text,
  reference_image_url text,
  status text default 'pending',
  created_at timestamp with time zone default now()
);

-- PRODUCTS
create table products (
  id serial primary key,
  name text not null,
  price integer not null,
  category text not null,
  image text not,
  description text,
  inventory integer default 100,
  is_active boolean default true,
  created_at timestamp default now()
);

insert into products (name, price, category, image, description) values
('CREDIBLE Box Tee - Noir', 450, 'T-shirts', 'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=800', 'Heavyweight 240gsm, puff print front. Drop 003.'),
('Ink Culture Hoodie', 850, 'Hoodies', 'https://images.unsplash.com/photo-1556821840-3a63f95609a7?w=800', 'Brushed fleece 380gsm, embroidered chest logo.'),
('Studio Cap - Gold Stitch', 350, 'Caps', 'https://images.unsplash.com/photo-1588850561407-ed78c282e89b?w=800', '6-panel unstructured, gold embroidery.'),
('Live It Cargo Pants', 750, 'Custom', 'https://images.unsplash.com/photo-1594633312681-425c7b97ccd1?w=800', 'Street cut, utility pockets, washed black.'),
('Wear It Oversized Tee - Cream', 480, 'T-shirts', 'https://images.unsplash.com/photo-1576566588028-4147f3842f27?w=800', 'Limited drop, 100% cotton.'),
('Ink It Zip Hoodie', 950, 'Hoodies', 'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?w=800', 'Drop 002, heavy zip.');

-- ORDERS
create table orders (
  id uuid primary key default uuid_generate_v4(),
  customer_email text not null,
  items jsonb not null,
  total integer not null,
  status text default 'pending',
  paystack_reference text,
  created_at timestamp default now()
);

-- GALLERY
create table gallery (
  id serial primary key,
  category text not null check (category in ('Tattoos','Piercings','Merchandise','Designs')),
  image_url text not null,
  title text,
  created_at timestamp default now()
);

-- Enable RLS and policies (public read, authenticated write for demo)
alter table bookings enable row level security;
alter table products enable row level security;
alter table orders enable row level security;
alter table gallery enable row level security;

create policy "Public read products" on products for select using (true);
create policy "Public read gallery" on gallery for select using (true);
create policy "Allow insert bookings" on bookings for insert with check (true);
create policy "Allow insert orders" on orders for insert with check (true);

-- Storage bucket for reference images
-- Create bucket via dashboard: storage -> new bucket -> name: reference-images, public: true
-- Policy: allow public upload
