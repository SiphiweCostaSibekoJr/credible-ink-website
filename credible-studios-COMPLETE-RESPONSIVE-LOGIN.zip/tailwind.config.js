/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html","./src/**/*.{js,ts,jsx,tsx}"],
  theme: {
    extend: {
      colors: { gold: { DEFAULT: '#D4AF37', light: '#E8C872', dark: '#B8962E' }, ink: { 900: '#0A0A0A', 800: '#111111', 700: '#1A1A1A', 600: '#242424' } },
      fontFamily: { display: ['Anton','Bebas Neue','sans-serif'], body: ['Inter','Space Grotesk','sans-serif'] }
    }
  },
  plugins: []
}