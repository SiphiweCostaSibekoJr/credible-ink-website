# Credible Studios — Wear It. Live It. Ink It.

Premium React + Vite + Tailwind site.

## Setup
npm install
npm run dev

## Env for Supabase
Create .env file:
VITE_SUPABASE_URL=your_url
VITE_SUPABASE_ANON_KEY=your_anon_key

Tables to create in Supabase:
- bookings (id uuid, name text, phone text, email text, service text, date date, time time, description text, placement text, size text, notes text, created_at timestamp)
- products (id, name, price, category, image, description, inventory int)
- orders (id, customer_email, items jsonb, total int, status)
- gallery (id, category, image_url, title)

Storage bucket: reference-images (public)

## Payment
Cart is ready. Replace checkout alert with:
- Paystack: use @paystack/inline-js
- Yoco or Stripe

## Deploy
npm run build -> deploy dist/ to Vercel / Netlify
