import { useState } from 'react'

export default function Auth({ onClose, onLogin }){
  const [isLogin,setIsLogin]=useState(true)
  const [email,setEmail]=useState('')
  const [password,setPassword]=useState('')
  const [name,setName]=useState('')

  const handleSubmit = (e) => {
    e.preventDefault()
    // Fake auth for now - save to localStorage, later connect Supabase
    const user = { email, name: name || email.split('@')[0], id: Date.now() }
    localStorage.setItem('credible_user', JSON.stringify(user))
    onLogin(user)
    onClose()
  }

  const handleGoogle = () => {
    const user = { email:'googleuser@gmail.com', name:'Google User', id: Date.now(), provider:'google' }
    localStorage.setItem('credible_user', JSON.stringify(user))
    onLogin(user)
    onClose()
  }

  return (
    <div className="fixed inset-0 z-[90] bg-black/80 backdrop-blur-sm p-4 grid place-items-center">
      <div className="bg-[#111] border border-white/10 w-full max-w-[400px] p-8 relative">
        <button onClick={onClose} className="absolute top-4 right-4 text-white/40 hover:text-white">X</button>
        <p className="text-gold text-[11px] tracking-[0.3em] uppercase">{isLogin ? 'Welcome Back' : 'Join Credible'}</p>
        <h2 className="font-display text-3xl uppercase mt-2">{isLogin ? 'Sign In' : 'Create Account'}</h2>
        <p className="text-xs text-white/50 mt-2">{isLogin ? 'Sign in to see prices and checkout' : 'Create account to shop Drop 003'}</p>

        <form onSubmit={handleSubmit} className="mt-8 space-y-4">
          {!isLogin && (
            <div>
              <label className="text-[10px] uppercase tracking-widest text-white/40">Full Name</label>
              <input value={name} onChange={e=>setName(e.target.value)} required={!isLogin} placeholder="Siphiwe Sibeko" className="mt-1 w-full bg-[#0A0A0A] border border-white/10 px-4 py-3 text-sm outline-none focus:border-gold/50" />
            </div>
          )}
          <div>
            <label className="text-[10px] uppercase tracking-widest text-white/40">Email</label>
            <input value={email} onChange={e=>setEmail(e.target.value)} type="email" required placeholder="you@gmail.com" className="mt-1 w-full bg-[#0A0A0A] border border-white/10 px-4 py-3 text-sm outline-none focus:border-gold/50" />
          </div>
          <div>
            <label className="text-[10px] uppercase tracking-widest text-white/40">Password</label>
            <input value={password} onChange={e=>setPassword(e.target.value)} type="password" required placeholder="••••••••" className="mt-1 w-full bg-[#0A0A0A] border border-white/10 px-4 py-3 text-sm outline-none focus:border-gold/50" />
          </div>
          <button type="submit" className="w-full bg-gold text-black py-4 text-[11px] font-bold uppercase tracking-widest mt-2">{isLogin ? 'Sign In' : 'Create Account'}</button>
        </form>

        <div className="mt-6">
          <div className="flex items-center gap-3"><div className="h-px bg-white/10 flex-1"></div><span className="text-[10px] text-white/30 uppercase">or</span><div className="h-px bg-white/10 flex-1"></div></div>
          <button onClick={handleGoogle} className="mt-4 w-full border border-white/20 py-3 text-[11px] uppercase tracking-widest flex items-center justify-center gap-2 hover:bg-white/5"><span>G</span> Continue with Google</button>
        </div>

        <p className="text-center text-[11px] text-white/40 mt-6">
          {isLogin ? "Don't have account? " : "Already have account? "}
          <button onClick={()=>setIsLogin(!isLogin)} className="text-gold underline">{isLogin ? 'Sign Up' : 'Sign In'}</button>
        </p>
        <p className="text-[9px] text-white/20 text-center mt-4 uppercase">Prices hidden until login • Secure checkout • 2098 Mngadi St</p>
      </div>
    </div>
  )
}
