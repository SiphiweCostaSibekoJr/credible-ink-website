import { useState } from 'react'

export default function ProductCard({ product, onAdd, user, onRequireLogin }){
  const [added,setAdded]=useState(false)
  const [size,setSize]=useState('M')

  const handleAdd = () => {
    if(!user){
      onRequireLogin()
      return
    }
    onAdd({...product, selectedSize:size, cartId: Date.now() + Math.random()})
    setAdded(true)
    setTimeout(()=>setAdded(false), 1500)
  }

  return (
    <div className="group border border-white/10 bg-[#111] hover:border-gold/30 transition flex flex-col">
      <div className="overflow-hidden aspect-[4/5] relative bg-[#0A0A0A]">
        <img src={product.image} alt={product.name} className="w-full h-full object-cover group-hover:scale-[1.03] transition duration-700" loading="lazy"/>
        <div className="absolute top-3 left-3 flex gap-2">
          <span className="bg-black/70 backdrop-blur text-[9px] tracking-widest uppercase px-2 py-1 border border-white/10">{product.category}</span>
          {product.badge && <span className="bg-gold text-black text-[9px] font-bold tracking-widest uppercase px-2 py-1">{product.badge}</span>}
        </div>
        {!user && <div className="absolute inset-0 bg-black/60 backdrop-blur-[1px] grid place-items-center"><p className="bg-white text-black text-[10px] font-bold uppercase tracking-widest px-3 py-2">Login to see price</p></div>}
      </div>
      <div className="p-4 md:p-5 flex flex-col flex-1">
        <h3 className="font-display text-[15px] md:text-lg uppercase leading-tight">{product.name}</h3>
        <p className="text-[11px] text-white/50 mt-1 line-clamp-2">{product.desc}</p>
        
        <div className="mt-3 flex gap-1">
          {['S','M','L','XL'].map(s=>(
            <button key={s} onClick={()=>setSize(s)} className={`w-7 h-7 text-[10px] border ${size===s ? 'bg-white text-black border-white' : 'border-white/20 text-white/50 hover:border-white/40'}`}>{s}</button>
          ))}
        </div>

        <div className="flex items-center justify-between mt-4 pt-4 border-t border-white/5">
          <div>
            {user ? (
              <>
                <p className="font-bold text-sm md:text-base">R{product.price}</p>
                <p className="text-[9px] text-white/30 uppercase">Incl. VAT • {product.stock || 'In Stock'}</p>
              </>
            ) : (
              <>
                <p className="text-[11px] text-white/30 uppercase tracking-widest">Sign in to see price</p>
                <p className="text-[9px] text-gold uppercase mt-1 cursor-pointer" onClick={onRequireLogin}>Tap to login →</p>
              </>
            )}
          </div>
          <button onClick={handleAdd} className={`text-[10px] tracking-widest uppercase px-4 py-2.5 font-bold transition ${added ? 'bg-green-500 text-black' : 'bg-white text-black hover:bg-gold'} `}>
            {added ? 'Added ✓' : 'Add'}
          </button>
        </div>
      </div>
    </div>
  )
}
