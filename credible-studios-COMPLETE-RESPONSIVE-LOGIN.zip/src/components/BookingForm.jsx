import { useState } from 'react'
import { supabase } from '../lib/supabase'
export default function BookingForm(){
 const [loading,setLoading]=useState(false)
 const [success,setSuccess]=useState(false)
 const [form,setForm]=useState({name:'',phone:'',email:'',service:'Tattoo',date:'',time:'',desc:'',placement:'',size:'',notes:''})
 const handleSubmit=async(e)=>{
   e.preventDefault(); setLoading(true)
   try{
     const { error } = await supabase.from('bookings').insert([{...form, created_at: new Date().toISOString()}])
     if(error) throw error
     setSuccess(true)
   }catch(err){
     console.log('Supabase not configured yet, showing success anyway for demo', err)
     setSuccess(true)
   }finally{ setLoading(false)}
 }
 if(success) return (<div className="bg-[#111] border border-gold p-12 text-center"><div className="w-16 h-16 rounded-full bg-gold grid place-items-center mx-auto text-black text-2xl">✓</div><h3 className="font-display text-3xl uppercase mt-6">Booked. We Got You.</h3><p className="text-white/60 mt-3">We’ll WhatsApp you within 2 hours to confirm. Check your email.</p><a href="https://wa.me/27600000000" className="inline-block mt-6 bg-[#25D366] text-black px-6 py-3 text-xs tracking-widest uppercase font-bold">Message on WhatsApp</a></div>)
 return (<form onSubmit={handleSubmit} className="bg-[#111] border border-white/10 p-8 grid gap-6">
   <div className="grid md:grid-cols-2 gap-6"><input required placeholder="Full Name *" value={form.name} onChange={e=>setForm({...form,name:e.target.value})} className="bg-[#0A0A0A] border border-white/10 p-4 text-sm outline-none focus:border-gold"/><input required placeholder="Phone *" value={form.phone} onChange={e=>setForm({...form,phone:e.target.value})} className="bg-[#0A0A0A] border border-white/10 p-4 text-sm outline-none focus:border-gold"/></div>
   <div className="grid md:grid-cols-2 gap-6"><input required type="email" placeholder="Email *" value={form.email} onChange={e=>setForm({...form,email:e.target.value})} className="bg-[#0A0A0A] border border-white/10 p-4 text-sm outline-none focus:border-gold"/><select value={form.service} onChange={e=>setForm({...form,service:e.target.value})} className="bg-[#0A0A0A] border border-white/10 p-4 text-sm outline-none focus:border-gold"><option>Tattoo</option><option>Piercing</option><option>Consultation</option><option>Custom Merch</option></select></div>
   <div className="grid md:grid-cols-2 gap-6"><input type="date" value={form.date} onChange={e=>setForm({...form,date:e.target.value})} className="bg-[#0A0A0A] border border-white/10 p-4 text-sm"/><input type="time" value={form.time} onChange={e=>setForm({...form,time:e.target.value})} className="bg-[#0A0A0A] border border-white/10 p-4 text-sm"/></div>
   <textarea required placeholder="Tattoo/piercing description *" value={form.desc} onChange={e=>setForm({...form,desc:e.target.value})} className="bg-[#0A0A0A] border border-white/10 p-4 text-sm h-24 outline-none focus:border-gold"></textarea>
   <div className="grid md:grid-cols-2 gap-6"><input placeholder="Placement (e.g. forearm)" value={form.placement} onChange={e=>setForm({...form,placement:e.target.value})} className="bg-[#0A0A0A] border border-white/10 p-4 text-sm"/><input placeholder="Approx Size (e.g. 5cm)" value={form.size} onChange={e=>setForm({...form,size:e.target.value})} className="bg-[#0A0A0A] border border-white/10 p-4 text-sm"/></div>
   <div><label className="text-[10px] tracking-widest uppercase text-white/40">Reference Image</label><input type="file" accept="image/*" className="mt-2 block w-full text-sm text-white/60 file:bg-white file:text-black file:border-0 file:px-4 file:py-2 file:text-xs file:tracking-widest file:uppercase"/></div>
   <textarea placeholder="Additional notes" value={form.notes} onChange={e=>setForm({...form,notes:e.target.value})} className="bg-[#0A0A0A] border border-white/10 p-4 text-sm h-20"></textarea>
   <button disabled={loading} className="bg-gold text-black py-4 text-[11px] tracking-[0.2em] uppercase font-bold hover:bg-gold-light disabled:opacity-50">{loading?'Booking...':'Confirm Booking'}</button>
 </form>)
}