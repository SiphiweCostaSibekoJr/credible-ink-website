export default function Hero(){
 return (<section className="min-h-[100vh] pt-[72px] grid lg:grid-cols-12 max-w-[1400px] mx-auto px-6 gap-6">
   <div className="lg:col-span-7 flex flex-col justify-center py-12">
     <p className="text-gold text-[11px] tracking-[0.3em] uppercase mb-6">Soweto • Johannesburg • Since 2019</p>
     <h1 className="font-display text-[14vw] lg:text-[7vw] leading-[0.85] uppercase">WEAR IT.<br/>LIVE IT.<br/><span className="text-gold">INK IT.</span></h1>
     <p className="mt-8 max-w-[480px] text-white/60 leading-relaxed">Johannesburg-based creative studio where skin becomes canvas and clothing becomes culture. No gimmicks, just clean lines, real art, premium streetwear.</p>
     <div className="mt-10 flex gap-3"><a href="#booking" className="bg-gold text-black px-8 py-4 text-[11px] tracking-[0.2em] uppercase font-bold">Book Appointment</a><a href="#merch" className="border border-white px-8 py-4 text-[11px] tracking-[0.2em] uppercase">Shop Merch</a></div>
     <div className="mt-12 flex gap-12 border-t border-white/10 pt-8"><div><p className="font-display text-4xl">500+</p><p className="text-[10px] tracking-widest text-white/40 uppercase">Inked</p></div><div><p className="font-display text-4xl">98%</p><p className="text-[10px] tracking-widest text-white/40 uppercase">Rated 5-Star</p></div><div><p className="font-display text-4xl">003</p><p className="text-[10px] tracking-widest text-white/40 uppercase">Merch Drop</p></div></div>
   </div>
   <div className="lg:col-span-5 grid grid-rows-2 gap-6 pb-12 lg:pt-12">
     <img src="https://images.unsplash.com/photo-1598371839696-5c5bb00bdc28?w=800" className="w-full h-[50vh] object-cover grayscale hover:grayscale-0 transition duration-700" alt="tattoo" loading="lazy"/>
     <img src="https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=800" className="w-full h-[40vh] object-cover" alt="merch" loading="lazy"/>
   </div>
 </section>)
}