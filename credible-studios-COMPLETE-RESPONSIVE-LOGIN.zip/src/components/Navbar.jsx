import { useState } from 'react'

export default function Navbar({ cartCount, onCartOpen, user, onLoginClick, onLogout }){
  const [menuOpen,setMenuOpen]=useState(false)
  return (
    <nav className="sticky top-0 z-50 bg-[#0A0A0A]/95 backdrop-blur border-b border-white/10">
      <div className="max-w-[1400px] mx-auto px-4 md:px-6 h-[64px] flex items-center justify-between">
        <div className="flex items-center gap-8">
          <a href="#" className="font-display text-xl md:text-2xl uppercase tracking-widest">Credible<span className="text-gold">.</span></a>
          <div className="hidden lg:flex items-center gap-6 text-[11px] tracking-widest uppercase text-white/60">
            <a href="#tattoos" className="hover:text-white">Tattoos</a>
            <a href="#piercings" className="hover:text-white">Piercings</a>
            <a href="#printing" className="hover:text-white">Printing</a>
            <a href="#merch" className="hover:text-white">Merch</a>
          </div>
        </div>

        <div className="flex items-center gap-2 md:gap-3">
          {user ? (
            <div className="hidden md:flex items-center gap-3">
              <span className="text-[11px] text-white/60">Hi, {user.name?.split(' ')[0]}</span>
              <button onClick={onLogout} className="text-[10px] uppercase border border-white/20 px-3 py-2 hover:bg-white/10">Logout</button>
            </div>
          ) : (
            <button onClick={onLoginClick} className="hidden md:block bg-white text-black text-[11px] font-bold uppercase tracking-widest px-4 py-2.5 hover:bg-gold transition">Sign In</button>
          )}
          <button onClick={onCartOpen} className="relative bg-[#111] border border-white/10 px-3 md:px-4 py-2.5 text-[11px] uppercase tracking-widest flex items-center gap-2">
            <span>Cart</span>
            <span className="bg-gold text-black text-[10px] font-bold w-5 h-5 grid place-items-center rounded-full">{cartCount}</span>
          </button>
          <button onClick={()=>setMenuOpen(!menuOpen)} className="lg:hidden border border-white/10 w-10 h-10 grid place-items-center text-white/70">☰</button>
        </div>
      </div>
      {menuOpen && (
        <div className="lg:hidden border-t border-white/10 bg-[#0A0A0A] px-4 py-6 space-y-4">
          <div className="flex flex-col gap-4 text-[11px] uppercase tracking-widest">
            <a href="#tattoos" onClick={()=>setMenuOpen(false)}>Tattoos</a>
            <a href="#piercings" onClick={()=>setMenuOpen(false)}>Piercings</a>
            <a href="#printing" onClick={()=>setMenuOpen(false)}>Printing — New</a>
            <a href="#merch" onClick={()=>setMenuOpen(false)}>Merch</a>
            <a href="#contact" onClick={()=>setMenuOpen(false)}>Contact — 2098 Mngadi St</a>
          </div>
          {!user ? (
            <button onClick={()=>{setMenuOpen(false); onLoginClick()}} className="w-full bg-gold text-black py-3 text-[11px] font-bold uppercase">Sign In to See Prices</button>
          ) : (
            <div className="pt-4 border-t border-white/10 flex justify-between items-center"><span className="text-xs">Hi, {user.name}</span><button onClick={onLogout} className="text-[11px] uppercase underline">Logout</button></div>
          )}
        </div>
      )}
    </nav>
  )
}
