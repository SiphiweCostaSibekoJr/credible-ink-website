export default function ProductCard({ product, onAdd }){
 return (<div className="group border border-white/10 bg-[#111] hover:border-gold/50 transition">
   <div className="overflow-hidden aspect-[4/5]"><img src={product.image} alt={product.name} className="w-full h-full object-cover group-hover:scale-105 transition duration-700" loading="lazy"/></div>
   <div className="p-5"><p className="text-[10px] tracking-widest text-white/40 uppercase">{product.category}</p><h3 className="font-display text-lg uppercase mt-1">{product.name}</h3><p className="text-xs text-white/50 mt-1">{product.desc}</p><div className="flex items-center justify-between mt-4"><p className="font-semibold">R{product.price}</p><button onClick={()=>onAdd(product)} className="bg-white text-black text-[10px] tracking-widest uppercase px-4 py-2 hover:bg-gold transition">Add to Cart</button></div></div>
 </div>)
}