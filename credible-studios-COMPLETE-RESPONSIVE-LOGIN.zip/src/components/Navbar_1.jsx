import { useState } from 'react'
export default function Navbar({ cartCount, onCartOpen }){
  const [open,setOpen]=useState(false)
  const links=['Tattoos','Piercings','Merch','Gallery','About','Booking']
  return (<nav className="fixed top-0 w-full z-50 bg-[#0A0A0A]/80 backdrop-blur-xl border-b border-white/10">
    <div className="max-w-[1400px] mx-auto px-6 h-[72px] flex items-center justify-between">
      <div className="flex items-center gap-2"><span className="font-display text-xl tracking-widest">CREDIBLE</span><span className="w-2 h-2 bg-gold rounded-full"></span><span className="font-display text-xl font-light">STUDIOS</span></div>
      <div className="hidden lg:flex items-center gap-8">{links.map(l=><a key={l} href={`#${l.toLowerCase()}`} className="text-[11px] tracking-[0.2em] uppercase text-white/60 hover:text-white transition">{l}</a>)}</div>
      <div className="flex items-center gap-3">
        <button onClick={onCartOpen} className="relative text-xs tracking-widest border border-white/20 px-4 py-2">CART ({cartCount})</button>
        <a href="#booking" className="hidden lg:block bg-gold text-black text-[11px] tracking-[0.2em] uppercase px-6 py-3 font-semibold hover:bg-gold-light transition">BOOK NOW</a>
        <button onClick={()=>setOpen(!open)} className="lg:hidden w-10 h-10 border border-white/20 grid place-items-center">☰</button>
      </div>
    </div>
    {open && <div className="lg:hidden bg-[#111] border-t border-white/10 p-6 flex flex-col gap-4">{links.map(l=><a key={l} href={`#${l.toLowerCase()}`} onClick={()=>setOpen(false)} className="font-display text-3xl uppercase">{l}</a>)}</div>}
  </nav>)
}