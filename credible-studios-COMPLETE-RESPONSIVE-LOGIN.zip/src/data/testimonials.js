export const testimonials = [
  { name:'Thabo M.', service:'Fine Line Tattoo', text:'Cleanest linework I\'ve seen. Credible lives up to the name - no cap.', rating:5 },
  { name:'Zanele K.', service:'Septum + Merch', text:'Piercing was quick, jewellery quality insane. Hoodie is heavyweight, real streetwear.', rating:5 },
  { name:'Lerato D.', service:'Custom Artwork', text:'They turned my Soweto story into ink. Professional, artistic, premium experience.', rating:5 },
]
