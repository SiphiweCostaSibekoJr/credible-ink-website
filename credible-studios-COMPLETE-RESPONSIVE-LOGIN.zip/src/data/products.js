export const products = [
  { id:1, name:'CREDIBLE Box Tee - Noir', price:450, category:'T-shirts', image:'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=800', desc:'Heavyweight 240gsm, puff print front. Drop 003.' },
  { id:2, name:'Ink Culture Hoodie', price:850, category:'Hoodies', image:'https://images.unsplash.com/photo-1556821840-3a63f95609a7?w=800', desc:'Brushed fleece 380gsm, embroidered chest logo.' },
  { id:3, name:'Studio Cap - Gold Stitch', price:350, category:'Caps', image:'https://images.unsplash.com/photo-1588850561407-ed78c282e89b?w=800', desc:'6-panel unstructured, gold embroidery.' },
  { id:4, name:'Live It Cargo Pants', price:750, category:'Custom', image:'https://images.unsplash.com/photo-1594633312681-425c7b97ccd1?w=800', desc:'Street cut, utility pockets, washed black.' },
  { id:5, name:'Wear It Oversized Tee - Cream', price:480, category:'T-shirts', image:'https://images.unsplash.com/photo-1576566588028-4147f3842f27?w=800', desc:'Limited drop, 100% cotton.' },
  { id:6, name:'Ink It Zip Hoodie', price:950, category:'Hoodies', image:'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?w=800', desc:'Drop 002, heavy zip.' },
]
export const tattooCategories = ['All','Lettering','Minimal/Tiny','Fine Line','Black & Grey','Custom Artwork','Graffiti/Street Art','Cover-ups']
export const piercingTypes = [
  { name:'Earlobe', price:'R150' },{ name:'Helix', price:'R250' },{ name:'Conch', price:'R300' },{ name:'Daith', price:'R300' },{ name:'Nose', price:'R250' },{ name:'Septum', price:'R300' },{ name:'Eyebrow', price:'R300' },{ name:'Lip', price:'R300' },{ name:'Navel', price:'R350' }
]
