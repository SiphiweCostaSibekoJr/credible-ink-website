export const galleryItems = [
  { id:1, category:'Tattoos', image:'https://images.unsplash.com/photo-1598371839696-5c5bb00bdc28?w=800', title:'Fine Line Script' },
  { id:2, category:'Tattoos', image:'https://images.unsplash.com/photo-1542727365-19732a80dcfd?w=800', title:'Black & Grey Portrait' },
  { id:3, category:'Piercings', image:'https://images.unsplash.com/photo-1617038220319-276d3cfab638?w=800', title:'Helix Stack' },
  { id:4, category:'Merchandise', image:'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=800', title:'Box Tee Noir' },
  { id:5, category:'Designs', image:'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=800', title:'Graffiti Study' },
  { id:6, category:'Tattoos', image:'https://images.unsplash.com/photo-1566870596934-83ba7a3f74aa?w=800', title:'Minimal Wave' },
  { id:7, category:'Piercings', image:'https://images.unsplash.com/photo-1535632066927-ab7c9ab60908?w=800', title:'Septum Gold' },
  { id:8, category:'Merchandise', image:'https://images.unsplash.com/photo-1556821840-3a63f95609a7?w=800', title:'Ink Culture' },
]
