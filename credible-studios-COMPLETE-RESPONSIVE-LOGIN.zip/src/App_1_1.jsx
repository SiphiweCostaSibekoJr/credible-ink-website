import { useState, useEffect } from 'react'
import Navbar from './components/Navbar'
import Hero from './components/Hero'
import ProductCard from './components/ProductCard'
import BookingForm from './components/BookingForm'
import Footer from './components/Footer'
import { products, tattooCategories, piercingTypes } from './data/products'
import { galleryItems } from './data/gallery'
import { testimonials } from './data/testimonials'

export default function App(){
  const [cart,setCart]=useState(()=>{ try{return JSON.parse(localStorage.getItem('credible_cart')||'[]')}catch{return []}})
  const [filter,setFilter]=useState('All')
  const [galleryFilter,setGalleryFilter]=useState('All')
  const [lightbox,setLightbox]=useState(null)
  const [showCart,setShowCart]=useState(false)
  useEffect(()=>localStorage.setItem('credible_cart', JSON.stringify(cart)),[cart])
  const addToCart=(p)=>setCart([...cart,p])
  const filteredTattoos = filter==='All' ? galleryItems.filter(i=>i.category==='Tattoos') : galleryItems.filter(i=>i.category==='Tattoos')
  const filteredGallery = galleryFilter==='All' ? galleryItems : galleryItems.filter(i=>i.category===galleryFilter)

  return (<div className="min-h-screen bg-[#0A0A0A] text-white selection:bg-gold selection:text-black">
    <Navbar cartCount={cart.length} onCartOpen={()=>setShowCart(true)} />
    <Hero />

    <section className="max-w-[1400px] mx-auto px-6 py-24 grid md:grid-cols-3 gap-6 border-t border-white/10" id="services">
      {[
        {k:'01', t:'TATTOOS', d:'Fine line, black & grey, custom artwork, graffiti. Clean, credible, no compromise.', img:'https://images.unsplash.com/photo-1542727365-19732a80dcfd?w=800'},
        {k:'02', t:'PIERCINGS', d:'Professional, sterile, titanium & gold. From lobe to daith, done right.', img:'https://images.unsplash.com/photo-1617038220319-276d3cfab638?w=800'},
        {k:'03', t:'MERCH', d:'Heavyweight tees, hoodies, caps. Streetwear that carries the studio.', img:'https://images.unsplash.com/photo-1556821840-3a63f95609a7?w=800'},
      ].map(s=><div key={s.k} className="group border border-white/10 p-8 bg-[#111] hover:border-gold/40 transition"><p className="text-gold text-xs">{s.k}</p><h3 className="font-display text-3xl uppercase mt-4">{s.t}</h3><p className="text-sm text-white/50 mt-3 leading-relaxed">{s.d}</p><div className="mt-8 overflow-hidden h-48"><img src={s.img} className="w-full h-full object-cover group-hover:scale-105 transition duration-700" loading="lazy"/></div></div>)}
    </section>

    <section id="tattoos" className="max-w-[1400px] mx-auto px-6 py-24">
      <div className="flex flex-wrap justify-between items-end gap-6"><h2 className="font-display text-5xl md:text-7xl uppercase">TATTOOS</h2><div className="flex flex-wrap gap-2">{tattooCategories.map(c=><button key={c} onClick={()=>setFilter(c)} className={`px-4 py-2 border text-[10px] tracking-widest uppercase ${filter===c?'bg-gold text-black border-gold':'border-white/20 text-white/60'}`}>{c}</button>)}</div></div>
      <div className="grid md:grid-cols-3 gap-6 mt-12">{galleryItems.filter(g=>g.category==='Tattoos').slice(0,6).map(item=><div key={item.id} className="group relative overflow-hidden aspect-[3/4] bg-[#111]"><img src={item.image} alt={item.title} className="w-full h-full object-cover group-hover:scale-105 transition duration-700" loading="lazy"/><div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent opacity-0 group-hover:opacity-100 transition flex items-end p-6"><p className="font-display uppercase">{item.title}</p></div></div>)}</div>
      <a href="#booking" className="inline-block mt-10 bg-gold text-black px-8 py-4 text-[11px] tracking-widest uppercase font-bold">Book a Tattoo</a>
    </section>

    <section id="piercings" className="bg-[#111] border-y border-white/10">
      <div className="max-w-[1400px] mx-auto px-6 py-24 grid lg:grid-cols-2 gap-12">
        <div><h2 className="font-display text-5xl md:text-7xl uppercase">PIERCINGS</h2><p className="text-white/60 mt-6 max-w-[480px]">Single-use needles, implant-grade titanium, gold options. Professional placement, real aftercare support.</p><div className="mt-10 grid grid-cols-2 gap-3">{piercingTypes.map(p=><div key={p.name} className="flex justify-between border border-white/10 p-4 bg-[#0A0A0A]"><span className="text-sm uppercase tracking-widest">{p.name}</span><span className="text-gold text-sm">{p.price}</span></div>)}</div><a href="#booking" className="inline-block mt-10 border border-white px-8 py-4 text-[11px] tracking-widest uppercase">Book a Piercing</a></div>
        <div className="bg-[#0A0A0A] border border-white/10 p-8"><h3 className="text-[11px] tracking-widest uppercase">Jewellery</h3><div className="mt-6 flex gap-3"><span className="px-3 py-2 bg-white/10 text-xs">Titanium</span><span className="px-3 py-2 bg-gold text-black text-xs font-bold">Gold</span><span className="px-3 py-2 bg-white/10 text-xs">Surgical Steel</span></div><h3 className="text-[11px] tracking-widest uppercase mt-10">Aftercare</h3><ul className="mt-4 space-y-3 text-sm text-white/60 list-disc pl-5"><li>Saline clean 2x daily, no twisting</li><li>No swimming / makeup for 2 weeks</li><li>Downsize after swelling goes</li><li>WhatsApp us any concerns - 24h reply</li></ul></div>
      </div>
    </section>

    <section id="merch" className="max-w-[1400px] mx-auto px-6 py-24">
      <div className="flex justify-between items-end"><h2 className="font-display text-5xl md:text-7xl uppercase">MERCH<br/><span className="text-white/20">DROP 003</span></h2><p className="hidden md:block text-xs tracking-widest text-white/40 uppercase max-w-[240px]">Heavyweight, puff & embroidery. Limited runs, no restock.</p></div>
      <div className="grid md:grid-cols-3 gap-6 mt-12">{products.map(p=><ProductCard key={p.id} product={p} onAdd={addToCart} />)}</div>
    </section>

    <section id="gallery" className="max-w-[1400px] mx-auto px-6 py-24 border-t border-white/10">
      <div className="flex flex-wrap justify-between items-end gap-6"><h2 className="font-display text-5xl md:text-7xl uppercase">GALLERY</h2><div className="flex flex-wrap gap-2">{['All','Tattoos','Piercings','Merchandise','Designs'].map(c=><button key={c} onClick={()=>setGalleryFilter(c)} className={`px-4 py-2 border text-[10px] tracking-widest uppercase ${galleryFilter===c?'bg-white text-black':'border-white/20 text-white/60'}`}>{c}</button>)}</div></div>
      <div className="columns-1 md:columns-3 gap-6 mt-12 space-y-6">{filteredGallery.map(item=><div key={item.id} onClick={()=>setLightbox(item)} className="break-inside-avoid group cursor-pointer relative overflow-hidden bg-[#111]"><img src={item.image} alt={item.title} className="w-full object-cover group-hover:scale-[1.02] transition duration-700" loading="lazy"/><div className="absolute bottom-0 left-0 right-0 p-4 bg-black/60 text-[10px] tracking-widest uppercase flex justify-between"><span>{item.title}</span><span className="text-gold">{item.category}</span></div></div>)}</div>
    </section>

    <section className="max-w-[1400px] mx-auto px-6 py-24 grid md:grid-cols-3 gap-6 border-y border-white/10">{testimonials.map(t=><div key={t.name} className="bg-[#111] border border-white/10 p-8"><p className="text-gold">★★★★★</p><p className="mt-4 text-sm leading-relaxed text-white/80">"{t.text}"</p><p className="mt-6 text-[11px] tracking-widest uppercase">{t.name} — {t.service}</p></div>)}</section>

    <section id="about" className="max-w-[1400px] mx-auto px-6 py-24 grid lg:grid-cols-2 gap-12">
      <div><h2 className="font-display text-5xl md:text-7xl uppercase">WE BUILT THIS<br/>ON CREDIBILITY.</h2><div className="mt-10 space-y-6 text-white/60 leading-relaxed"><p>Credible Studios started in a backroom in Soweto. No investors, just a machine, a sketchbook, and a word that meant everything: Credible.</p><p>In a game full of gimmicks, we stayed clean. Clean lines, clean studio, clean business. Tattoos that age well. Piercings that heal right. Merch you actually wear, not just buy.</p><p className="text-white font-medium">We’re not a tattoo shop that sells clothes. We’re a lifestyle house that happens to ink.</p></div></div>
      <div className="bg-[#111] border border-white/10 p-8"><img src="https://images.unsplash.com/photo-1566870596934-83ba7a3f74aa?w=1000" className="w-full h-[400px] object-cover" alt="studio"/><div className="grid grid-cols-3 gap-6 mt-8 border-t border-white/10 pt-8"><div><p className="font-display text-3xl">2019</p><p className="text-[10px] text-white/40 uppercase">Founded</p></div><div><p className="font-display text-3xl">Soweto</p><p className="text-[10px] text-white/40 uppercase">Roots</p></div><div><p className="font-display text-3xl">Gold Std</p><p className="text-[10px] text-white/40 uppercase">Standard</p></div></div></div>
    </section>

    <section id="booking" className="max-w-[900px] mx-auto px-6 py-24"><h2 className="font-display text-5xl md:text-6xl uppercase text-center">BOOK YOUR SESSION</h2><p className="text-center text-white/50 mt-4 text-sm">Fill it in properly - we review every booking and reply within 2 hours on WhatsApp.</p><div className="mt-12"><BookingForm/></div></section>

    <section id="contact" className="bg-[#111] border-t border-white/10"><div className="max-w-[1400px] mx-auto px-6 py-16 grid md:grid-cols-2 gap-12"><div><h3 className="font-display text-4xl uppercase">PULL UP OR<br/>HIT US ONLINE</h3><div className="mt-8 flex flex-col gap-4"><a href="https://wa.me/27692921306" className="bg-[#25D366] text-black px-6 py-4 inline-flex w-fit text-[11px] tracking-widest uppercase font-bold">WhatsApp Us — 069 292 1306</a><div className="text-sm text-white/60 space-y-1"><p>Phone: +27 69 292 1306</p><p>Email: crediblestudios@gmail.com</p><p>Instagram: @credible_ink_tattoos</p><p>2098 Mngadi Street, Jabulani</p><p>Tue - Sun: 10am - 7pm</p></div></div></div><div className="bg-[#0A0A0A] border border-white/10 h-[320px] grid place-items-center text-white/20 text-xs tracking-widest uppercase">Map — 2098 Mngadi Street, Jabulani - Map</div></div></section>

    <Footer />

    {showCart && <div className="fixed inset-0 z-[60] flex justify-end"><div className="absolute inset-0 bg-black/60" onClick={()=>setShowCart(false)}></div><div className="relative w-full max-w-[420px] bg-[#111] border-l border-white/10 p-8 flex flex-col"><div className="flex justify-between items-center"><h3 className="font-display text-2xl uppercase">Cart ({cart.length})</h3><button onClick={()=>setShowCart(false)} className="text-white/40">✕</button></div><div className="mt-8 flex-1 space-y-4 overflow-auto">{cart.length===0?<p className="text-white/40 text-sm">Cart empty. Add some heat.</p>:cart.map((c,i)=><div key={i} className="flex gap-4 border-b border-white/10 pb-4"><img src={c.image} className="w-16 h-16 object-cover"/><div><p className="text-sm uppercase">{c.name}</p><p className="text-gold text-sm">R{c.price}</p></div></div>)}</div><div className="border-t border-white/10 pt-6"><p className="flex justify-between"><span>Total</span><span className="font-bold">R{cart.reduce((s,i)=>s+i.price,0)}</span></p><button onClick={()=>alert('Connect to Paystack / Stripe / Yoco - ready for integration')} className="mt-6 w-full bg-gold text-black py-4 text-[11px] tracking-widest uppercase font-bold">Checkout — Paystack / Stripe Ready</button><p className="text-[10px] text-white/30 mt-3 text-center uppercase">Frontend ready for Supabase orders + payments</p></div></div></div>}

    {lightbox && <div className="fixed inset-0 z-[70] bg-black/90 p-6 grid place-items-center" onClick={()=>setLightbox(null)}><img src={lightbox.image} className="max-w-[90vw] max-h-[90vh] object-contain"/><p className="absolute bottom-8 text-[11px] tracking-widest uppercase text-white/60">{lightbox.title} — {lightbox.category}</p></div>}
  </div>)
}